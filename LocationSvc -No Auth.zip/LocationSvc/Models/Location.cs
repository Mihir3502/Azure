﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocationSvc.Models
{
    public class Location
    {
        public int Latitute { get; set; }
        public int Longitude { get; set; }
    }
}